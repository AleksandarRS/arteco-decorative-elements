<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<span class="frm-with-left-icon">
	<?php FrmAppHelper::icon_by_class( 'frmfont frm_user_icon', array( 'aria-hidden' => 'true' ) ); ?>
	<input type="text" value="<?php esc_attr_e( 'User ID fields will not show in your form.', 'formidable' ); ?>" disabled />
</span>
