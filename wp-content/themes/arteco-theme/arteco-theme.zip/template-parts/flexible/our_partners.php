<?php
$main_title = get_sub_field('main_title');
?>
<section class="our-partners-section">
    <div class="container">
        <div class="row our-partners-row">
            <div class="col-md-12 main-title-section-heading align-center">
                
            </div>
            
        </div> <!-- /.row our-partners-row -->
    </div> <!-- /.container -->
</section>

